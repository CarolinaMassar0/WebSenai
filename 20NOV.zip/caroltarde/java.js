const trocarElemento = document.querySelector('.trocar');

trocarElemento.addEventListener('mouseover', () => {
  trocarElemento.innerText = 'BITE';
});

trocarElemento.addEventListener('mouseout', () => {
  trocarElemento.innerText = 'BECAUSE IT´S THE EARTH';
});