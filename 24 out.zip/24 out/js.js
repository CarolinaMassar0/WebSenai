// function calcular(){
//   let num = Number(window.prompt('Digite um número:'))
//   let res = document.querySelector('section#result')
//   res.innerHTML =  `<p> O número a ser analisando aqui será o <strong>${num}</strong></p>`

//   res.innerHTML += `<p> O seu valor absoluto é <strong>${Math.abs(num)}</strong></p> `

//   res.innerHTML += `<p> O seu valor inteiro é ${Math.trunc(num)}</p> `

//   res.innerHTML += `<p> O seu valor inteiro mais proximo é${Math.round(num)}</p> `

//   res.innerHTML += `<p> A sua raiz quadrada é ${Math.sqrt(num)}</p> `

//   res.innerHTML += `<p> A sua raiz cubica é ${Math.cbrt(num)}</p> `

//   res.innerHTML += `<p>O valor de ${num}<sup>2</sup> ${Math.pow(num,2)}</p> `

//   res.innerHTML += `<p>O valor de ${num}<sup>3</sup> ${Math.pow(num,3)}</p> `
// }
// PARTE DOIS
// let contador = 0
// let res = document.querySelector('section#result')

// function contar(){
//     contador ++
//     res.innerHTML = `<p>O contador está em <strong>${contador}</strong> Cliques </p>`
// }

// function zerar(){
// contador = 0
// res.innerHTML = null
// } 
//PARTE TRÊS
function calculo() {
    let a = Number(document.getElementById('a').value);
    let b = Number(document.getElementById('b').value);
    let c = Number(document.getElementById('c').value);

    document.querySelector('#result').innerHTML =
    `a soma de <mark> ${a} + ${b} </mark> divido por <strong> 
    ${c}</strong> é igual a:<strong> ${(a + b) / c}</strong>`
}

