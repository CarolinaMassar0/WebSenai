function funcao1(){
    alert("iniciar")
}
function funcao2(){
    alert("pausar")
}
function inicio(){
    let nome = window.prompt("Qual seu nome?")
    window.alert(`Olá, ${nome} ! É um prazer te conhecer`)
}
