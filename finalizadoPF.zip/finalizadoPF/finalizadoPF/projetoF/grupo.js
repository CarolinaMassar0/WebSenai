let contador = 0;


function aumentar() {
  contador += 250;
  document.getElementById('contador').textContent = "R$" + contador;
}

function diminuir() {
  if (contador > 0) {
    contador -= 250;
    document.getElementById('contador').textContent = "R$" + contador;
  }
}
let contador2 = 0;

function aumentar2() {
  contador += 250;
  document.getElementById('contador2').textContent = "R$" + contador;
}

function diminuir2() {
  if (contador > 0) {
    contador -= 250;
    document.getElementById('contador2').textContent = "R$" + contador;
  }
}
const rangeInput = document.getElementById('rangeInput');
const displayText = document.getElementById('displayText');

rangeInput.addEventListener('input', function () {
  const value = this.value;
  displayText.textContent = `Mes: ${value}`;
});

function calcularTotal() {
  var valorInvestido = parseFloat(document.getElementById('contador').innerText.replace('R$', '')); // Valor inicial do investimento
  var valorDepositoMensal = parseFloat(document.getElementById('contador2').innerText.replace('R$', '')); // Valor mensal de depósito
  var tempoInvestimento = parseInt(document.getElementById('rangeInput').value); // Tempo de investimento em meses

  var totalInvestimento = valorInvestido + (valorDepositoMensal * tempoInvestimento);

 
  document.getElementById('resultado').innerHTML = "O total do valor investido após " + tempoInvestimento + " meses será de R$" + totalInvestimento.toFixed(2);
}

